#  text based game 

ans_yes = ["YES","Yes","yes","Y","y"]
ans_no = ["NO","No","no","N","n"]

ans_1 = input("""
        welcome! LET;s START THE ADVANTURE ARE YOOU READDY - (YES / NO ) :- """)

if ans_1 in ans_yes:
    print("""\n you are going home in your car when you see a women in dirty clothes running towards you and  asking for a ride home.
    will you give her a ride home. (yes/no)""")
    ans_2 = input("enter your ans :- ")

    if ans_2 in ans_yes:
        print(""" \nAfter 5minutes, you are stopped at a checkpoint and police asks you if you seen a suspicious women.
    Will you say (yes/no)""")
        ans_3 = input("enter your ans :- ")
    
        if ans_3 in ans_yes:
            print("\n you are an honest person . She was a murderer & you won the Game ")
        elif ans_3 in ans_no:
            print("\n you helped a murderer . Now go to jail . Game over")
        else:
            print("\n you typed the wrong input . GOODBAYE!")

