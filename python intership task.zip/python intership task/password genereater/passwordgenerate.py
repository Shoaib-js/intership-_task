import random
import string

print("welcome to Password Generator")

#  input the length of passsword 
length_p = int(input("\n Enter the length of the password :- "))

#  define data 
lower = string.ascii_lowercase
upper = string.ascii_uppercase
num = string.digits
symbols = string.printable

# print(lower)
# print(upper)
# print(num)
# print(symbols)

#  combine the data
all = lower  + upper + num + symbols

#  use random
temp  = random.sample(all,length_p)

# create list password into string password
passsword = "".join(temp)

print("\n",passsword)